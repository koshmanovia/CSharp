﻿namespace Pinger
{
    public class hostStatus
    {
    }
}